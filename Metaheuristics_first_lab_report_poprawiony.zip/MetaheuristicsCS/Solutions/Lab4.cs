﻿using Crossovers;
using EvaluationsCLI;
using Generators;
using MetaheuristicsCS.Optimizers.PopulationOptimizers;
using Mutations;
using Optimizers;
using Optimizers.PopulationOptimizers;
using Selections;
using StopConditions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaheuristicsCS.Solutions
{
    class Lab4 : ALab<bool>
    {
        private void firstExercise(int seed)
        {
            IEvaluation<bool>[] problems = GenerateProblems();

        }

        private static void Lab4BinaryGA(IEvaluation<bool> evaluation, ASelection selection, ACrossover crossover, int? seed)
        {
            IterationsStopCondition stopCondition = new IterationsStopCondition(evaluation.dMaxValue, 100);

            BinaryRandomGenerator generator = new BinaryRandomGenerator(evaluation.pcConstraint, seed);
            BinaryBitFlipMutation mutation = new BinaryBitFlipMutation(0, evaluation, seed);

            GeneticAlgorithm<bool> ga = new GeneticAlgorithm<bool>(evaluation, stopCondition, generator, selection, crossover, mutation, 20);

            ga.Run();

            ReportOptimizationResult(ga.Result);
        }

        private static void Lab4BinaryMutatedGA(IEvaluation<bool> evaluation, ASelection selection, ACrossover crossover, int? seed)
        {
            IterationsStopCondition stopCondition = new IterationsStopCondition(evaluation.dMaxValue, 100);

            BinaryRandomGenerator generator = new BinaryRandomGenerator(evaluation.pcConstraint, seed);
            BinaryBitFlipMutation mutation = new BinaryBitFlipMutation(0, evaluation, seed);

            MutatedIslandGA miga = new MutatedIslandGA(evaluation, stopCondition, generator, selection, crossover, mutation, 20);

            miga.Run();

            ReportOptimizationResult(miga.Result);
        }

        private static void Lab4Max3SAT(int? seed)
        {
            Console.WriteLine("Trap Max3SAT GA");
            Lab4BinaryGA(new CBinaryMax3SatEvaluation(100),
                         new TournamentSelection(2, seed),
                         new OnePointCrossover(0.5, seed),
                         seed);
            Console.WriteLine("Trap Max3SAT MIGA");
            Lab4BinaryMutatedGA(new CBinaryMax3SatEvaluation(100),
                         new TournamentSelection(2, seed),
                         new OnePointCrossover(0.5, seed),
                         seed);
        }

        private static void Lab4TrapTournamentSelectionOnePointCrossover(int? seed)
        {
            Console.WriteLine("Trap Tournament GA");
            Lab4BinaryGA(new CBinaryStandardDeceptiveConcatenationEvaluation(3, 50),
                         new TournamentSelection(2, seed),
                         new OnePointCrossover(0.5, seed),
                         seed);
            Console.WriteLine("Trap Tournament MIGA");
            Lab4BinaryMutatedGA(new CBinaryStandardDeceptiveConcatenationEvaluation(3, 50),
                         new TournamentSelection(2, seed),
                         new OnePointCrossover(0.5, seed),
                         seed);
        }

        private static void Lab4TrapRouletteWheelSelectionUniformCrossover(int? seed)
        {
            Console.WriteLine("Trap Roulette GA");
            Lab4BinaryGA(new CBinaryStandardDeceptiveConcatenationEvaluation(3, 50),
                         new RouletteWheelSelection(seed),
                         new UniformCrossover(0.5, seed),
                         seed);
            Console.WriteLine("Trap Roulette MIGA");
            Lab4BinaryMutatedGA(new CBinaryStandardDeceptiveConcatenationEvaluation(3, 50),
                         new RouletteWheelSelection(seed),
                         new UniformCrossover(0.5, seed),
                         seed);
        }

        public override void Run(int[] seeds)
        {
            foreach (int seed in seeds)
            {
                firstExercise(seed);
            }
        }

        protected override string FormatOptimizerParameters(AOptimizer<bool> optimizer)
        {
            throw new NotImplementedException();
        }

        protected override IEvaluation<bool>[] GenerateProblems()
        {
            int[] max3Satblocks = { 5, 10, 20, 30, 40, 50 };
            int[] isgGenes = { 25, 49, 100, 484 };
            int[] nkLandscapeGenes = { 10, 50, 100, 200 };
            int[] standardDeceptiveBlocks = { 10, 50, 100 };
            
            int nProblems = max3Satblocks.Length +  //Max3Sat problem
                isgGenes.Length +                   //Ising Sping Glass
                nkLandscapeGenes.Length +           //NK fitness landscapes
                standardDeceptiveBlocks.Length;     //Standard Deceptive problem with length 3

            int iterator = 0;
            IEvaluation<bool>[] problems = new IEvaluation<bool>[nProblems];

            //Max3Sat problem
            foreach (var genes in max3Satblocks)
            {
                problems[iterator] = new CBinaryMax3SatEvaluation(genes);
                iterator++;
            }

            //Ising Sping Glass
            foreach (var genes in isgGenes)
            {
                problems[iterator] = new CBinaryIsingSpinGlassEvaluation(genes);
                iterator++;
            }

            //NK fitness landscapes
            foreach (var genes in nkLandscapeGenes)
            {
                problems[iterator] = new CBinaryNKLandscapesEvaluation(genes);
            }

            //Standard Deceptive problem with length 3
            foreach (var functions in standardDeceptiveBlocks)
            {
                problems[iterator] = new CBinaryStandardDeceptiveConcatenationEvaluation(3, functions);
                iterator++;
            }

            return problems;
        }
    }
}
